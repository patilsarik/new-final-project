package POM;

import java.time.Duration;
import java.util.List;
import java.util.ListIterator;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Zerodha_HomePage {
	//path of options on page
	@FindBy(xpath="//span[@text()='Orders']") private WebElement orders;
	@FindBy(xpath="//span[text()='Dashboard']") private WebElement dashboard;
	@FindBy(xpath="//span[text()='Holdings']") private WebElement Holding;
	@FindBy(xpath="//span[text()='Positions']") private WebElement Positions;
	@FindBy(xpath="//span[text()='Funds']") private WebElement Funds;
	@FindBy(xpath="//span[text()='Apps']") private WebElement App;
	//path of search buttons
	@FindBy(xpath="//input[@autocorrect='off']") private WebElement search;
	@FindBy(xpath="//button[@class='button-blue buy']") private WebElement buyButton;
	@FindBy(xpath="//button[@class='button-orange sell']") private WebElement sellbutton;
	@FindBy(xpath="//span[@class='icon icon-align-center']") private WebElement marketDepth;
	@FindBy(xpath="//span[@class='icon icon-trending-up']") private WebElement graph;
	@FindBy(xpath="//span[@class='icon icon-trash']") private WebElement delete;
	@FindBy(xpath="//span[@class='icon icon-ellipsis']") private WebElement more;
	//path of Buy/sell window
	@FindBy(xpath="//input[@id='radio-194']") private WebElement intradayradio;
	@FindBy(xpath="//input[@id='radio-195']") private WebElement longtermradio;
	@FindBy(xpath="//input[@label='Qty.']") private WebElement quntity;
	@FindBy(xpath="//input[@label='Price']") private WebElement price;
	@FindBy(xpath="//input[@label='Trigger price']")private WebElement trigger;
	@FindBy(xpath="//label[@for='radio-200']")private WebElement marketorder;
	@FindBy(xpath="//label[@for='radio-201']")private WebElement limitorder;
	@FindBy(xpath="//label[@for='radio-203']")private WebElement stoploss;
	@FindBy(xpath="//label[@for='radio-204']")private WebElement marketstoploss;
	@FindBy(xpath="//button[@type='submit']")private WebElement Buystock;
	@FindBy(xpath="//span[@class='symbol']") private List<WebElement> searchable;
	
	@FindBy(xpath="(//span[@class=\"tradingsymbol\"])[1]")private WebElement index0;
	@FindBy(xpath ="(//button[@class=\"button-blue\"])[1]")private WebElement Buy;


public Zerodha_HomePage(WebDriver driver) {
	PageFactory.initElements(driver, this);
}

public void clickOnsearch(String stock ) {
	search.click();
	search.sendKeys(stock);
	
//	for(WebElement Search:searchable)	{
//	   if(Search.getText().equals(stockvalue)) {
//			Search.click();
//			Actions action=new Actions(driver);
//			action.moveToElement(Search).click().perform();
//			action.moveToElement(buyButton).click();
//			
//		}
//	} 

}
public void ClickByeButtonShare(WebDriver driver) {
 Actions action = new Actions(driver);
 action.moveToElement(index0).perform();
 action.moveToElement(Buy);
 action.click();
 action.perform();
 }	

public void clickindex0(WebDriver driver) {
	
 }

public void clickonBuyButton() {
	
	
	}
public void clickOnintradayradio() {
	intradayradio.click();
}
public void selectquntity(String numbers) {
	quntity.sendKeys(numbers);
}
public void selectPrice(String pric) {
	price.sendKeys(pric);
}
public void clickOnMO() {
	marketorder.click();
}
public void clickOnbuy() {
	Buy.click();	
}







}